![REACTKIT](https://reactkit.eogresources.com/img/reactkit-logo-text.svg)

Read more at [ReactKit / Platform / ReactKit Starter](https://reactkit.eogresources.com/docs/platform/starter-kit)

# Getting Started

### Step 1: Bootstrap
```sh
yarn install
```

### Step 2: ENV
Then, you need to copy the server `.env.sample` file to your `.env`

```sh
cp server/.env.example server/.env
```

### Step 3: Starting Up

```sh
yarn go
```
** Please don't try to start at 3000. Please read the [docs linked to above](https://reactkit.eogresources.com/docs/platform/starter-kit) ** 

# Deployment

As of 2021, we recommend the following setup using out [Test Automation and CICD](https://reactkit.eogresources.com/docs/testautomation/ideal-cicd-flow):

1. Use CICD with auto preview URLs and auto Deployment with automated testing. Details.
2. Deploy using heypat (rather than scripts)
3. Use https://oidcadminstg.eogresources.com/ for clientid/secret for stage and https://oidcadmin.eogresources.com/ for production
4. Store clientid/secret in server/.env. For production, set inside heypat deploy

