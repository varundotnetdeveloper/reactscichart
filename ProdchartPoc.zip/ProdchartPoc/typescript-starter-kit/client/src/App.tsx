/* eslint-disable */
import React, { useEffect } from 'react';
import { ConnectedRouter } from 'connected-react-router';
import { Route, Switch } from 'react-router-dom';
import { DescriptionCard } from '@eog/geode-core';
import { Button, Avatar, LinearProgress } from '@material-ui/core';
import { SessionWall } from './features/SessionWall/SessionWall';
import { Page } from './components/Page';
import Theme from './Theme';
import PalaPala from './features/PalaPala/PalaPala';
import { history } from './store/reducers';
import { NoMatchPage } from './components/NotFound';
import { store } from './store';
import Scichart from './components/example';


declare global {
  interface Window {
    mobileSupport?: {
      onApplicationReady: () => void;
    };
    store: typeof store
  }
}

const BoringWelcomeComponentThatYouShouldDelete = () => (
  <DescriptionCard
    avatar={(
      <Avatar
        alt='ReactKit'
        src='https://reactkit.eogresources.com/img/reactkit-logo.svg'
      />
    )}
    title='Welcome to ReactKit'
    subheader='Oh Hai There'
    content={[
      'ReactKit is a series of technologies built upon open source ',
      'methologies in order or to be super awesome.',
    ].join(' ')}
    elevation={1}
    rightActions={
      <Button color='primary' variant='contained' component='a' href='https://reactkit.eogresources.com' target='_blank' rel='noopener noreferrer'>Visit ReactKit</Button>
    }
  />
);

const Logout = () => {
  useEffect(() => {
    window.location.href = '/basic/logout';
  }, []);
  return <LinearProgress />;
};

const App: React.FC = () => {
  useEffect(() => {
    if (window.mobileSupport) {
      window.mobileSupport.onApplicationReady();
    }
  }, []);

  return (
    <Theme>
      <ConnectedRouter history={history}>
      <Switch>
              <Route
                exact
                path='/'
                component={Scichart}
              />
              <Route exact path='/logout' component={Logout} />
              <Route exact path='/logged_out' component={Logout} />
              <Route component={NoMatchPage} />
            </Switch>
      </ConnectedRouter>
    </Theme>
  );
};

export default App;
