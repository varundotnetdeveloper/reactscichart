import { createMuiTheme } from '@material-ui/core/styles';
import vhCheck from 'vh-check';
import merge from 'deepmerge';
import { geodeColors } from '@eog/geode-colors';

export declare type UnbindFunction = () => void;
export declare type ComputeCallback = (result?: Result) => void;
export interface Sizes {
  vh: number;
  windowHeight: number;
  offset: number;
  isNeeded: boolean;
  value: number;
}
export declare type ComputeSizeMethod = () => Sizes;
export interface Configuration {
  cssVarName?: string;
  redefineVh?: boolean;
  method?: ComputeSizeMethod;
  force?: boolean;
  bind?: boolean;
  updateOnTouch?: boolean;
  onUpdate?: ComputeCallback;
}
export interface Result extends Sizes {
  unbind: UnbindFunction;
  recompute: ComputeSizeMethod;
}

const defaultOptions = {
  subtract: [],
  includeUnit: true,
};

const sum = (numbers: number[]) => {
  const reducer = (result: number, current: number) => result + current;
  return numbers.reduce(reducer, 0);
};

const verticalHeight = (v: number, options: Configuration, vhResult: Result) => {
  const normOptions = { ...defaultOptions, ...options };

  const height = vhResult.vh - vhResult.offset;
  const minsSum = sum(normOptions.subtract);
  const result = (v * height) / 100;
  const finalResult = result - minsSum;

  if (normOptions.includeUnit) {
    return `${finalResult}px`;
  }

  return finalResult;
};

export default (overrides = {}) => {
  const vhResult: Result = vhCheck();

  const options = {
    layout: {
      vh: (v: number, opts: any) => verticalHeight(v, opts, vhResult),
    },
    geode: geodeColors,
  };

  const t = createMuiTheme(overrides);
  return merge(t, options);
};
