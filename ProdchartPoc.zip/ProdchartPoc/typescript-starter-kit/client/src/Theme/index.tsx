import React, { useEffect } from 'react';
import {} from '@eog/geode-core';
import {
  darkPalette,
  lightPalette,
  geodeColors,
  typography,
  ExtendedTheme as GeodeTheme,
} from '@eog/geode-colors';
import { useMediaQuery } from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import { ThemeProvider } from '@material-ui/styles';
import makeBaseTheme from './createBaseMuiTheme';
import { DarkModeContext } from './DarkModeContext';

export type ExtendedTheme = GeodeTheme;

const AppTheme: React.FC = ({ children }) => {
  const OSPrefersDarkMode = useMediaQuery('(prefers-color-scheme: dark)');
  const [prefersDarkMode, updateDarkMode] = React.useState<boolean>(
    OSPrefersDarkMode,
  );

  useEffect(() => {
    updateDarkMode(OSPrefersDarkMode);
  }, [updateDarkMode, OSPrefersDarkMode]);

  const toggleTheme = React.useCallback(() => {
    updateDarkMode(!prefersDarkMode);
  }, [updateDarkMode, prefersDarkMode]);

  const theme = React.useMemo(
    () => makeBaseTheme({
      palette: prefersDarkMode ? darkPalette : lightPalette,
      geode: geodeColors,
      typography,
    }),
    [prefersDarkMode],
  );

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <DarkModeContext.Provider
        value={{
          prefersDarkMode,
          toggleTheme,
        }}
      >
        {children}
      </DarkModeContext.Provider>
    </ThemeProvider>
  );
};

export default AppTheme;
