import React from 'react';

import { CheckSquareFill, DeviceMobileRotate } from '@eog/geode-iconsv2';
import { ExitToApp, Home } from '@material-ui/icons';

export type PageNavItem = {
  text: string;
  icon?: React.ReactNode;
  pathname: string;
  disabled?: boolean;
  chevron?: boolean;
};

export type PageHelperItem = {
  text: string;
  icon?: React.ReactNode;
  pathname?: string;
  disabled?: boolean;
  chevron?: boolean;
};

export const MainNavItems: PageNavItem[] = [
  {
    text: 'Home',
    icon: <Home />,
    pathname: '/',
  },
];

export const GroupNavItems: PageNavItem[] = [
  {
    text: 'Nav 1',
    icon: <CheckSquareFill />,
    pathname: '/nav1',
  },
];

export const HelperNavItems: PageHelperItem[] = [
  {
    text: 'Sign Out',
    icon: <ExitToApp />,
    pathname: '/logout',
    chevron: true,
  },
  {
    text: 'Flip Rail',
    icon: <DeviceMobileRotate />,
  },
];
