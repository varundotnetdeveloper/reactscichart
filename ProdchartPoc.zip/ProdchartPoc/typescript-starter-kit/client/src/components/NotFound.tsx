import React from 'react';
import { useTheme, Typography, Button } from '@material-ui/core';
import { geodeDarken } from '@eog/geode-colors';
import { makeStyles } from '@material-ui/styles';
import { Link } from 'react-router-dom';
import { ExtendedTheme } from '../Theme';

function NotFoundSVG(props: React.SVGProps<SVGSVGElement>) {
  const theme = useTheme();
  return (
    // eslint-disable-next-line react/jsx-props-no-spreading
    <svg viewBox='0 0 512 512' {...props}>
      <path
        d='M496 40v24H16V40a24.006 24.006 0 0124-24h432a24.006 24.006 0 0124 24z'
        fill={theme.palette.primary.main}
      />
      <g fill={geodeDarken(theme.palette.primary.main, 1)}>
        <path d='M472 8H40A32.03 32.03 0 008 40v432a32.03 32.03 0 0032 32h432a32.03 32.03 0 0032-32V40a32.03 32.03 0 00-32-32zm16 464a16.021 16.021 0 01-16 16H40a16.021 16.021 0 01-16-16V72h464zm0-416H24V40a16.021 16.021 0 0116-16h432a16.021 16.021 0 0116 16z' />
        <circle cx={39} cy={40} r={8} />
        <circle cx={64} cy={40} r={8} />
        <circle cx={88} cy={40} r={8} />
        <path d='M456 424H232a8 8 0 000 16h224a8 8 0 000-16zM424 448h-96a8 8 0 000 16h96a8 8 0 000-16zM456 448h-8a8 8 0 000 16h8a8 8 0 000-16zM288 376a32.036 32.036 0 0032-32V200a32.036 32.036 0 00-32-32h-64a32.036 32.036 0 00-32 32v144a32.036 32.036 0 0032 32zm-80-32V200a16.019 16.019 0 0116-16h64a16.019 16.019 0 0116 16v144a16.019 16.019 0 01-16 16h-64a16.019 16.019 0 01-16-16zM464 272a8 8 0 01-8 8h-16v88a8 8 0 01-16 0v-88h-80a8 8 0 01-8-8v-96a8 8 0 0116 0v88h72v-88a8 8 0 0116 0v88h16a8 8 0 018 8zM168 264h-16v-88a8 8 0 00-16 0v88H64v-88a8 8 0 00-16 0v96a8 8 0 008 8h80v88a8 8 0 0016 0v-88h16a8 8 0 000-16zM56 104h104a8 8 0 000-16H56a8 8 0 000 16zM56 128h32a8 8 0 000-16H56a8 8 0 000 16zM112 112a8 8 0 000 16h8a8 8 0 000-16z' />
      </g>
    </svg>
  );
}

const useStyles = makeStyles((theme: ExtendedTheme) => ({
  container: {
    width: '100%',
    height: theme.layout?.vh(100, { subtract: [100] }),
    flexDirection: 'column',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
}));

export const NoMatchPage: React.FC = () => {
  const classes = useStyles();

  return (
    <div className={classes.container}>
      <Typography variant='h6'>
        Page Not found -
        {' '}
        <Button component={Link} to='/' color='secondary'>Return Home</Button>
      </Typography>

      <NotFoundSVG height='60vh' width='80vw' />
    </div>
  );
};
