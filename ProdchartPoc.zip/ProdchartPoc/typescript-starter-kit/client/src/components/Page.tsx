/* eslint-disable */
import { ExtendedTheme } from '@eog/geode-colors';
import
{
  GeodeAppBar,
  GeodeRail,
  HelperNavItem,
  NavItem,
  NavItems,
} from '@eog/geode-core';
import { Avatar, IconButton } from '@material-ui/core';
import { Sun, Moon } from '@eog/geode-iconsv2';
import { createStyles, makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import { push } from 'connected-react-router';
import React, { FC } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouteMatch } from 'react-router-dom';
import { getUserDetails } from '../features/SessionWall/selectors';
import { DarkModeContext } from '../Theme/DarkModeContext';
import { HelperNavItems, MainNavItems } from './NavItems';

const drawerWidthOpen = 240;
const drawerWidthClosed = 72;

const useStyles = makeStyles((theme: ExtendedTheme) => createStyles({
  root: {
    display: 'grid',
  },
  scrollable: {
    height: theme.layout!.vh(100, { subtract: [70] }),
    overflowY: 'scroll',
    padding: theme.spacing(2),
  },
  appBar: {
    [theme.breakpoints.down('sm')]: {
      margin: 0,
      transition: 'none !important',
      width: '100%',
    },
    marginLeft: drawerWidthClosed,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    width: `calc(100% - ${drawerWidthClosed}px)`,
  },
  appBarShift: {
    [theme.breakpoints.down('sm')]: {
      margin: 0,
      transition: 'none !important',
      width: '100%',
    },
    marginLeft: drawerWidthOpen,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    width: `calc(100% - ${drawerWidthOpen}px)`,
  },
}));
export type Orientation = 'vertical' | 'horizontal';

export const Page: FC = ({ children }) => {
  const [orientation, setOrientation] = React.useState<Orientation>('vertical');
  const handleOrientation = () => setOrientation(prevValue => (prevValue === 'vertical' ? 'horizontal' : 'vertical'));
  const classes = useStyles();
  const { prefersDarkMode, toggleTheme } = React.useContext(DarkModeContext);

  const [open, setOpen] = React.useState(true);
  const railToggleHandler = () => setOpen(o => !o);
  const dispatch = useDispatch();

  const goTo = React.useCallback(
    (url: string) => {
      setOpen(false);
      dispatch(push(url));
    },
    [dispatch, setOpen],
  );

  const user = useSelector(getUserDetails);

  return (
    <div
      className={clsx(classes.root, {
        [classes.appBar]: orientation === 'vertical',
        [classes.appBarShift]: orientation === 'vertical' && open,
      })}
    >
      <GeodeRail
        appName='StarterKit'
        variant='permanent'
        open={open}
        orientation={orientation}
        helperActions={HelperNavItems.map(({ text, icon, pathname }) => (
          <HelperNavItem
            text={text}
            icon={icon}
            onClick={pathname ? () => goTo(pathname) : handleOrientation}
            open={open}
            orientation={orientation}
          />
        ))}
      >
        <NavItems open={open} orientation={orientation}>
          {MainNavItems.map(({ text, icon, pathname }) => (
            <NavItem
              key={text + pathname}
              text={text}
              icon={icon}
              selected={!!useRouteMatch({ path: pathname, exact: true })}
              onClick={() => goTo(pathname)}
              open={open}
              orientation={orientation}
            />
          ))}
        </NavItems>
      </GeodeRail>
      <GeodeAppBar
        appActions={(
          <IconButton color='inherit' onClick={() => toggleTheme()}>
            {prefersDarkMode ? (
              <Sun />
            ) : (
              <Moon />
            )}
          </IconButton>
        )}
        workerImage={(
          <IconButton>
            <Avatar src={`/avatar/worker/${user?.workerId}.png`} />
          </IconButton>
        )}
        position='sticky'
        onRailToggle={railToggleHandler}
        railOrientation={orientation}
      />
      <div className={classes.scrollable}>{children}</div>
    </div>
  );
};
