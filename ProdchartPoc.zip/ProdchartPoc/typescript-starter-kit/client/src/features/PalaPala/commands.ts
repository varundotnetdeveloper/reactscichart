import { createAsyncAction } from 'async-selector-kit';
import fetchVersion from '../../api/fetchVersion';
import { actions } from './reducer';
import * as selectors from './selectors';

export const [watchPalapalaChangesActions] = createAsyncAction({
  id: 'palapala-watch-changes',
  // dispatchActions: false, // if you don't want logging of this
  async: (store, status, currentVersion, currentStatus, pausedUntil) => async () => {
    if (currentStatus === 'outdated') return;
    const now = Date.now();
    if (currentStatus === 'paused' && pausedUntil < now) {
      const delay = pausedUntil - now;
      await new Promise(res => setTimeout(res, delay));
    }
    try {
      const version = await fetchVersion();
      if (version > currentVersion) {
        store.dispatch(actions.newVersionReceived());
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.warn(`Failed to fetch version: ${e}`);
    }
  },
}, [selectors.getCurrentVersion, selectors.getStatus, selectors.getPausedUntil]);

export const watchPalapalaChanges = () => {
  setInterval(() => watchPalapalaChangesActions(), 5 * 60 * 1000);
};

export const [reloadWithDelay] = createAsyncAction({
  id: 'reload-because-of-palapala',
  async: () => async () => {
    await new Promise(res => setTimeout(res, 500));
    window.location.reload(true);
  },
}, []);
