import { PayloadAction, createSlice } from '@reduxjs/toolkit';

export enum PalaPalaStatus {
  paused = 'paused',
  current = 'current',
  unknown = 'unknown',
  outdated = 'outdated',
}

interface TimestampAction {
  time: number;
}

const initialState = {
  status: PalaPalaStatus.unknown,
  currentVersion: Number(process.env.REACT_APP_PALAPALA_VERSION || '0'),
  pausedUntil: 0,
};

const palaPalaSlice = createSlice({
  name: 'palaPala',
  initialState,
  reducers: {
    begin: (state, action: PayloadAction<TimestampAction>) => {
      state.status = PalaPalaStatus.current;
      state.currentVersion = action.payload.time;
    },
    wasPaused: (state, action: PayloadAction<TimestampAction>) => {
      state.status = PalaPalaStatus.paused;
      state.pausedUntil = action.payload.time;
    },
    newVersionReceived: (state) => {
      state.status = PalaPalaStatus.outdated;
    },
  },
});

export const { actions } = palaPalaSlice;

export const { reducer } = palaPalaSlice;
