import { createSelector } from 'reselect';
import { IState } from '../../store/reducers';

const palaPala = (state: IState) => state.palaPala;

export const getStatus = createSelector(
  palaPala,
  state => state.status,
);
export const getCurrentVersion = createSelector(
  palaPala,
  state => state.currentVersion,
);
export const getPausedUntil = createSelector(
  palaPala,
  state => state.pausedUntil,
);
