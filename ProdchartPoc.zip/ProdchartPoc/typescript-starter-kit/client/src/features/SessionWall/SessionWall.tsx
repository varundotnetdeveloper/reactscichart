import React, { FC } from 'react';
import { useSelector } from 'react-redux';
import { makeStyles, useTheme } from '@material-ui/core';
import ClipLoader from 'react-spinners/ScaleLoader';
import { isUserAuthenticated } from './selectors';

// SessionWall is THE SSO implementation
// SessionWall shows a loading indicator a new session is required
// It then dispatches an action to refetch a session
// If THAT comes back with a location header, it will redirect over there
// That will come back with the new session.

type Props = {
  children: React.ReactNode;
};

const useStyles = makeStyles({
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
    position: 'absolute',
    height: '100vh',
    width: '100vw',
  },
});

export const SessionWall: FC<Props> = ({ children }) => {
  const interactionRequired = !useSelector(isUserAuthenticated);
  const classes = useStyles();
  const theme = useTheme();

  if (interactionRequired) {
    return (
      <div className={classes.container}>
        <ClipLoader
          height={150}
          width={30}
          color={theme.palette.primary.main}
        />
      </div>
    );
  }

  return <>{children}</>;
};
