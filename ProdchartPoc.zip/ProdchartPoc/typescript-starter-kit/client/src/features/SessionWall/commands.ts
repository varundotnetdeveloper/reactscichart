/* eslint-disable import/no-cycle */
import { refresh } from '@eog/client-oidc';
import { createAsyncAction } from 'async-selector-kit';
import { actions, MobileIntegration, Ticket } from './reducer';
import { isExpiredOrAboutToExpire, isMobile } from './selectors';

const apiFetchTicket = async () => {
  const type = 'basic';
  const deleteFl = false; // type === 'private';
  const response = await fetch(`/${type}/userinfo?delete=${deleteFl}`, { credentials: 'include' });
  if (response.status === 401) {
    const location = response.headers.get('Location');
    if (location) {
      window.location.href = location;
    }
    throw Error('refreshing session');
  }
  if (response.ok) {
    const ticket: Ticket = await response.json();
    return ticket;
  }
  throw Error(String(response.status));
};

const [fetchAndMaintainTicketCommand] = createAsyncAction(
  {
    id: 'Fetch the ticket and keep it from expiring',
    async: ({ dispatch }, status, needToInvalidate, isMobileWrapped) => async () => {
      if (needToInvalidate) {
        try {
          if (isMobileWrapped === MobileIntegration.FALSE) {
            await refresh('basic'); // try to extend the ticket silently
          }
          const ticket = await apiFetchTicket();
          dispatch(actions.setSession(ticket));
        } catch (e) {
          dispatch(actions.revoke());
        }
      }
    },
  },
  [isExpiredOrAboutToExpire, isMobile],
);
export const fetchAndMaintainTicket = () => {
  fetchAndMaintainTicketCommand();
  setInterval(() => fetchAndMaintainTicketCommand(), 10000);
};
