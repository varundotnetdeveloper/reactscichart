/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable camelcase */
import { PayloadAction, createSlice } from '@reduxjs/toolkit';

export type Ticket = {
  access_token: string;
  at_hash: string;
  aud: string;
  department_name: string;
  division_name: string;
  exp: number;
  family_name: string;
  given_name: string;
  iat: number;
  iss: string;
  misoo_token: string;
  misoo_token_expire_at: string;
  mobile_integration: boolean;
  name: string;
  sub: string;
  ticket_name: string;
  worker_id: number;
};

export type User = {
  departmentName: string;
  divisionName: string;
  firstName: string;
  lastName: string;
  username: string;
  workerId: number;
};

export enum MobileIntegration {
  UNKNOWN,
  TRUE,
  FALSE,
}

const initialState: SessionState = {
  mobileIntegration: MobileIntegration.UNKNOWN,
  ticket: null,
  user: null,
};

type SessionState = {
  mobileIntegration: MobileIntegration;
  ticket: null | Ticket;
  user: null | User;
};

const sessionSlice = createSlice({
  name: 'session',
  initialState,
  reducers: {
    setSession(state, action: PayloadAction<Ticket>) {
      const {
        mobile_integration,
        department_name,
        division_name,
        given_name,
        family_name,
        sub,
        worker_id,
      } = action.payload;
      state.ticket = action.payload;
      state.user = {
        departmentName: department_name,
        divisionName: division_name,
        firstName: given_name,
        lastName: family_name,
        username: sub,
        workerId: worker_id,
      } as User;
      state.mobileIntegration = mobile_integration
        ? MobileIntegration.TRUE
        : MobileIntegration.FALSE;
    },
    revoke(state) {
      state.user = null;
      state.ticket = null;
    },
  },
});

export const { actions } = sessionSlice;

export const { reducer } = sessionSlice;
