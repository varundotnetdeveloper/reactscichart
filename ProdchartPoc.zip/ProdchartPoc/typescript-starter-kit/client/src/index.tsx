import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import App from './App';
import { watchPalapalaChanges } from './features/PalaPala/commands';
import { fetchAndMaintainTicket } from './features/SessionWall/commands';
import { store } from './store';

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root'),
  () => {
    fetchAndMaintainTicket();
    watchPalapalaChanges();
  },
);
