/* eslint-disable spaced-comment */
/// <reference types="react-scripts" />
