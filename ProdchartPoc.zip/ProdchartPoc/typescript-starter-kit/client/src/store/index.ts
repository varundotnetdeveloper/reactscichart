import { startLogging } from '@eog/react-logging';
// @ts-ignore
import awsExports from '@eog/react-logging/lib/aws-exports';
import { makeReduxLoggerMiddleware, OptionsModel } from '@eog/react-logging/lib/redux';
import { EOGEnvironments } from '@eog/redux-saga-tracer';
import { configureStore } from '@reduxjs/toolkit';
import { createMiddleware } from 'async-selector-kit';
import Amplify, { Analytics } from 'aws-amplify';
import { routerMiddleware } from 'connected-react-router';
import packageJson from '../../package.json';
import reducers, { history } from './reducers';

Amplify.configure(awsExports);

const loggingEnvironment = (process.env.REACT_APP_DATA_ENV || 'local') as EOGEnvironments;
const APPNAME = 'APPNAME';

// type which will be used throughout the app
export type IState = ReturnType<typeof reducers>;

const middlewares = [
  makeReduxLoggerMiddleware({} as OptionsModel),
  routerMiddleware(history),
  createMiddleware(),
];

export const store = configureStore({
  devTools: true,
  reducer: reducers,
  middleware: middlewares,
});

window.store = store;

const getUsername = () => {
  const state: IState = window.store.getState();
  return state.session.user ? state.session.user.username : undefined;
};

startLogging({
  Analytics,
  getUsername,
  getOtherAttributes: () => ({
    appName: `${APPNAME}-${loggingEnvironment}`,
    appVersion: packageJson.version,
  }),
});
