import { connectRouter } from 'connected-react-router';
import { createBrowserHistory } from 'history';
import { combineReducers } from '@reduxjs/toolkit';
import { createReducer } from 'async-selector-kit';
import { reducer as SessionReducer } from '../features/SessionWall/reducer';
import { reducer as PalaPalaReducer } from '../features/PalaPala/reducer';

export const history = createBrowserHistory();

const combinedReducers = combineReducers({
  session: SessionReducer,
  palaPala: PalaPalaReducer,
  router: connectRouter(history),
  AsyncSelector: createReducer(),
});

export default combinedReducers;

// type which will be used throughout the app
export type IState = ReturnType<typeof combinedReducers>;
