const { hideBin } = require('yargs/helpers');
const yargs = require('yargs');
const { Octokit } = require('@octokit/rest');

yargs(hideBin(process.argv))
  .scriptName('announce-deployment')
  .command(
    'announce [repo] [branch] [commit] [url]',
    'announce deployment in GH comments',
    (yargs) => {
      yargs
        .positional('repo', {
          describe:
            'Name of repository being reployed, in the form of owner/repository',
          required: true,
        })
        .positional('branch', {
          type: 'string',
          describe: 'branch name in jenkins job (ie PR-8)',
          required: true,
        })
        .positional('commit', {
          describe: 'Commit SHA that was deployed',
          required: true,
        })
        .positional('url', {
          describe: 'URL that image was deployed to',
          required: true,
        });
    },
    async (argv) => {
      const GIT_TOKEN = argv.gitToken;
      const REPO_STR = argv.repo;
      const URL = argv.url;
      const branchName = argv.branch;
      const { commit } = argv;

      if (!/pr-\d+/i.test(branchName)) {
        console.log('Branch is not a pull request. Skipping announcement');
        process.exit(0);
      }

      const [, pull_number] = branchName.split('-');

      const octokit = new Octokit({
        auth: GIT_TOKEN,
        baseUrl: 'https://git.eogresources.com/api/v3',
      });

      const [owner, repo] = REPO_STR.split('/');

      try {
        const body = `Commit ${commit} has been deployed and is available at ${URL}`;
        console.info(`Posting comment: ${body}`);
        // github PR and issue comment api are the same endpoint
        await octokit.issues.createComment({
          owner,
          repo,
          issue_number: pull_number,
          body,
        });
        console.info('Success');
      } catch (err) {
        console.log(err);
      }
    },
  )
  .option('git-token', {
    describe: 'Git token to use to use API',
    type: 'string',
    required: true,
    global: true,
  })
  .help().argv;
