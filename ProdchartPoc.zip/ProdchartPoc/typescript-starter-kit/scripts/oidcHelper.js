/* eslint-disable no-console */
const api = require('@eog/oidc-api-client');
const { hideBin } = require('yargs/helpers');
const yargs = require('yargs');

function authorize(argv) {
  const CLIENT_ID = argv['auth-client-id'];
  const CLIENT_SECRET = argv['auth-client-secret'];

  return api.auth.loginWithClientCredentials(CLIENT_ID, CLIENT_SECRET);
}

yargs(hideBin(process.argv))
  .scriptName('oidc-helper')
  .command(
    'add [app] [url]',
    'add url to OIDC app',
    // eslint-disable-next-line @typescript-eslint/no-shadow
    (yargs) => {
      yargs
        .positional('app', {
          describe: 'Target app client ID',
        })
        .positional('url', {
          describe: 'Url to add',
        });
    },
    async (argv) => {
      try {
        const token = await authorize(argv);
        const CLIENT_ID = argv.app;
        const URL = argv.url;
        console.info(`Adding url ${URL} to ${CLIENT_ID}`);

        const docId = `Client:${CLIENT_ID}`;
        const meta = {
          type: 'client',
          id: docId,
        };
        const doc = await api.one.get(token, meta);
        const urlIdx = doc.payload.redirect_uris.indexOf(URL);
        if (urlIdx !== -1) {
          console.info('URL already registered in app');
          process.exit(0);
        }

        const res = await api.one.patch(token, {
          operations: [
            { op: 'add', path: '/payload/redirect_uris/-', value: URL },
          ],
          meta,
        });
        console.info(res);
        console.info('Success!');
      } catch (err) {
        console.error('Error adding url: ');
        console.error(err);
        process.exit(1);
      }
    },
  )
  .command(
    'delete [app] [url]',
    'remove url from OIDC app',
    (yargs) => {
      yargs
        .positional('app', {
          describe: 'Target app client ID',
        })
        .positional('url', {
          describe: 'url to remove',
        });
    },
    async (argv) => {
      try {
        const token = await authorize(argv);
        const CLIENT_ID = argv.app;
        const URL = argv.url;
        console.info(`Removing URL ${URL} from ${CLIENT_ID}`);

        const docId = `Client:${CLIENT_ID}`;
        const meta = {
          type: 'client',
          id: docId,
        };

        const doc = await api.one.get(token, meta);
        const urlIdx = doc.payload.redirect_uris.indexOf(URL);
        if (urlIdx === -1) {
          console.info("URL doesn't exist in app");
          process.exit(0);
        }
        await api.one.patch(token, {
          operations: [
            { op: 'remove', path: `/payload/redirect_uris/${urlIdx}` },
          ],
          meta,
        });
        console.info('Success!');
      } catch (err) {
        console.error('Error adding URL: ');
        console.error(err);
        process.exit(1);
      }
    },
  )
  .option('auth-client-id', {
    describe: 'OIDC app client ID',
    type: 'string',
  })
  .option('auth-client-secret', {
    describe: 'OIDC app client secret',
    type: 'string',
  });

const argv = yargs.argv;
