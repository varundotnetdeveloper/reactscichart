import express from 'express';

export interface AuthenticatedRequest extends express.Request {
  ticket: {
    claims: {
      sub: string;
    },
    id_token: string;
    access_token: string;
  }
}
