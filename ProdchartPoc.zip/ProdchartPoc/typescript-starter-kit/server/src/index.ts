import compression from 'compression';
import helmet from 'helmet';
import express, { Response, NextFunction } from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import cookieSession from 'cookie-session';
import path from 'path';
import * as env from 'env-var';
import userImageProxy from '@eog/full-stack-user-image-proxy';
import get from 'lodash/get';
import set from 'lodash/set';
import { AuthenticatedRequest } from './AuthenticatedRequest';

const NODE_ENV = env.get('NODE_ENV').asString();
const PORT = env.get('PORT').default(8888).asPortNumber();
const REACT_APP_DATA_ENV = env.get('REACT_APP_DATA_ENV').asString();

const DISCOVER_ENDPOINT = env.get('OIDC_DISCOVER_ENDPOINT').required().asUrlString();
const ORIGIN_ENDPOINT_FOR_SIGNOUT = env.get('ORIGIN_ENDPOINT_FOR_SIGNOUT').required().asUrlString();
const OIDC_CLIENT_ID = env.get('OIDC_CLIENT_ID').required().asString();
const OIDC_CLIENT_SECRET = env.get('OIDC_CLIENT_SECRET').required().asString();

const OVERRIDE_OIDC = env.get('OVERRIDE_OIDC').default('false').asString();

const APPLICATION_NAME = 'starterkit-default';
// APM visible at https://logapi.eogresources.com/app/apm
const apm = require('elastic-apm-node').start({
  serviceName: `${APPLICATION_NAME}-${REACT_APP_DATA_ENV || 'local'}`,
  serverUrl: 'http://eslog-swarm.eogresources.com:8200',
  active: NODE_ENV === 'production',
});

const palapalaVersionCheck = require('@eog/palapala-express');
const OIDC = require('@eog/express-oidc');

const app = express();

const runApp = async () => {
  app.set('trust proxy', 1);

  app.use(helmet());
  app.use(compression());
  app.use(cors());
  app.use(bodyParser.json());

  let OIDC_ENV = '';
  if (NODE_ENV !== 'production') {
    OIDC_ENV = 'local';
  } else if (REACT_APP_DATA_ENV === 'production') {
    OIDC_ENV = 'prod';
  } else {
    OIDC_ENV = 'stg';
  }
  app.use(
    cookieSession({
      name: `.${APPLICATION_NAME}-${OIDC_ENV}`,
      keys: ['2ab7ccbdb41d280953bcfade2ea97fd435f606ed', '73bde8719a6cfe0e534317ca8a252b7ab7614137'],
    }),
  );

  const mobileIntegration = OVERRIDE_OIDC.toLowerCase() === 'true';

  const providerOptions = {
    keys: ['101025fb2fb0cc56ab900d712decab2c', '0d2a575ea1e7fc9361975007a9881a5c'],
    ticketName: 'basic',
    scope: 'openid offline_access profile misoo_token eog_profile',
    redirectPath: '/basic/callback',
    origin: ORIGIN_ENDPOINT_FOR_SIGNOUT,
    discover: DISCOVER_ENDPOINT,
    client_id: OIDC_CLIENT_ID,
    client_secret: OIDC_CLIENT_SECRET,
    params: {
      hide_when_login_hint: false,
      login_message: '',
    },
    overrideOIDCUrl: mobileIntegration ? `${APPLICATION_NAME}-${OIDC_ENV}://auth/${'basic'}` : false,
  };
  const basicProvider = await OIDC.createOIDCProvider(app, providerOptions);

  if (mobileIntegration) {
    OIDC.integrateMobileApplication({
      app,
      clients: {
        basic: basicProvider,
      },
      AES_SECRET_KEY: providerOptions.keys[0],
    });
  }

  const appendUserContext = (req: AuthenticatedRequest, _res: Response, next: NextFunction) => {
    if (!req.ticket) {
      next();
      return;
    }
    const username = req.ticket.claims.sub;
    apm.setUserContext({ username });
    next();
  };

  app.use(palapalaVersionCheck);
  app.use(basicProvider.authorizeRedirect);
  app.use(appendUserContext);

  const enableImageProxy = (req : AuthenticatedRequest, _res, next) => {
    const token = get(req, 'ticket.access_token');
    set(req, 'session.userContext.Token', token);
    next();
  };
  app.get(
    '/avatar/:classification/:userId(\\d+).png',
    enableImageProxy,
    userImageProxy,
  );
  const pathToAppDirectory = path.resolve(__dirname, 'dist/app');

  OIDC.renderApplication({
    app,
    buildDirectoryPath: pathToAppDirectory,
    openBrowserOn: PORT,
    waitForPorts: [3000],
  });
};

runApp();
